#include <stdio.h>
#include <stdlib.h>

void limpa(){
    system("clear");
}

typedef struct LIVRO{
    int idLivro;  //auto incremento //chave primaria
    int anoPublicacao;
    char titulo[30]; //naonulo
    char editora[30];
    char isbn[20]; //naonulo
}LIVRO;

typedef struct LEITOR{
    int idLeitor;  //auto incremento //chave primaria
    char nome[30]; //naonulo
    char fone[20];  //naonulo
    int endereco;
    int cidade;
    int estado;
}LEITOR;

typedef struct AUTOR{
    int idAutor;  //auto incremento
    char nomeAutor[20];
    char sobrenomeAutor[20];
}AUTOR;

typedef struct AUTORDOLIVRO{
    int autorID; //naonulo
    int livroID; //naonulo
    int sequence; //naonulo
}AUTORDOLIVRO;

void LendoArquivo(char nome[],char tipo[])
{
    char ch;
    FILE *fp = fopen(nome,"r");
    AUTOR aut;
    LIVRO liv;
    LEITOR leit;
    AUTORDOLIVRO autliv;
    if(!fp)//Caso o arquivo nao tenha sido aberto corretamente
        printf("Erro na abertura do arquivo de entrada\n");
    else{
        while((ch=fgetc(fp))!=EOF){
            printf("%c",ch);
            if(ch=='-'){
                if(strcmp(tipo,"Autor")==0){

                }
                else if(strcmp(tipo,"Livro")==0){
                }
                else if(strcmp(tipo,"Leitor")==0){
                }
                else if(strcmp(tipo,"Autor do Livro")==0){
                }
            }
        }
    }
    scanf("%s");
	fclose(fp);
}

void CriaArquivo(char nome[])
{
    char ch;
    FILE *fp = fopen(nome,"r");
	if(!fp){//Caso o arquivo nao tenha sido aberto corretamente
        puts("OI");
    	fp=fopen(nome,"w");
    	if(fp)
            puts("Sucesso na criacao do arquivo\n");
        else
            puts("Erro na criacao do arquivo\n");
    }
	else{
        fclose(fp);
        puts("Arquivo ja existe!\nDeseja recriar o arquivo?(Esta opcao deleta todos os dados do arquivo)\n");
        fp=fopen(nome,"w");
        if(fp)
            puts("Sucesso na criacao do arquivo\n");
        else
            puts("Erro na criacao do arquivo\n");
    }
	fclose(fp);
}

void UpdateArquivo(char nome[])
{
    char ch;
    FILE *fp = fopen(nome,"w");

	if(!fp)
	{//Caso o arquivo nao tenha sido aberto corretamente
    	printf("Erro na abertura do arquivo de entrada\n");
	}
	else
	{
        fprintf(fp,"Escreve que somos ULALA");
	}
	fclose(fp);

}

void DeletaArquivo(char nome[]){

}

int menu_CRUD(char nome[])
{
    limpa();
	int opc=-1;
	char *tipo;
	if(strcmp(nome,"autor.txt")==0)
        tipo="Autor";
	if(strcmp(nome,"livro.txt")==0)
        tipo="Livro";
	if(strcmp(nome,"leitor.txt")==0)
        tipo="Leitor";
	if(strcmp(nome,"autordolivro.txt")==0)
        tipo="Autor Do Livro";
	while((opc<=0) || (opc>4))
	{
        printf("\n CRUD \n");
        printf("\nDigite 1 - Para CRIAR o Arquivo da Entidade %s",tipo);
        printf("\nDigite 2 - Para LER o arquivo da Entidade %s",tipo);
        printf("\nDigite 3 - Para dar UPDATE no arquivo  da Entidade %s",tipo);
        printf("\nDigite 4 - Para DELETAR o arquivo, da Entidade %s,  (você perderá todos os dados)",tipo);
        printf("\nDigite 0 - para SAIR\n");
        scanf("%i",&opc);
        limpa();
        if(opc==1)
            CriaArquivo(nome);
        else if(opc==2)
            LendoArquivo(nome,tipo);
        else if(opc==3)
            UpdateArquivo(nome);
        else if(opc==4)
            DeletaArquivo(nome);
        else if(opc==0)
            return;
        else
            printf("\nOpção Inválida, Digite algo para continuar\n");
	}
	return opc;
}

int menu_entidade()
{
    limpa();
	int opc=-1;
	while((opc<0) || (opc>4))
	{
        printf("\n ENTIDADES \n");
        printf("\nDigite 1 - Para Mexer com a Entidade AUTOR");
        printf("\nDigite 2 - Para Mexer com a Entidade LEITOR");
        printf("\nDigite 3 - Para Mexer com a Entidade LIVRO");
        printf("\nDigite 4 - Para Mexer com a Entidade AUTOR DO LIVRO");
        printf("\nDigite 0 - para SAIR\n");
        scanf("%i",&opc);
        if(opc==1)
            menu_CRUD("autor.txt");
        else if(opc==2)
            menu_CRUD("leitor.txt");
        else if(opc==3)
            menu_CRUD("livro.txt");
        else if(opc==4)
            menu_CRUD("autordolivro.txt");
        else if(opc==0)
            return 0;
        else
            printf("\nOpção Inválida, Digite algo para continuar\n");
	}
    return opc;
}
